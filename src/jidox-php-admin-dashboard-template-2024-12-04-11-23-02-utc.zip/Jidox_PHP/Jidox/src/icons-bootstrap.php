
<?php include 'partials/main.php'; ?>

<head>
    <title>Bootstrap Icons | Jidox - Bootstrap 5 Admin & Dashboard Template</title>
    <?php include 'partials/title-meta.php'; ?>
    <?php include 'partials/head-css.php'; ?>
</head>

<body>
    <!-- Begin page -->
    <div class="wrapper">

        <?php include 'partials/menu.php'; ?>

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex justify-content-between align-items-md-center flex-md-row flex-column">
                                <h4 class="page-title">Bootstrap Icons</h4>
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Jidox</a></li>
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Icons</a></li>
                                    <li class="breadcrumb-item active">Bootstrap Icons</li>
                                </ol>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Icons</h5>
                                    <p class="text-muted mb-2">Use class <code>&lt;i class=&quot;bi bi-123&quot;&gt;&lt;/i&gt;</code></p>
                                    <div class="row icons-list-demo" id="bootstrap-icons"></div>
                                </div> <!-- end card body -->
                            </div> <!-- end card -->
                        </div> <!-- end col -->
                    </div> <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->

            <?php include 'partials/footer.php'; ?>

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->
    </div>

    </div>
    <!-- END wrapper -->


    <?php include 'partials/right-sidebar.php'; ?>

    <?php include 'partials/footer-scripts.php'; ?>

    <!-- BootStrap Icons Demo js -->
    <script src="assets/js/pages/demo.bootstrapicons.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>
<script src="assets/js/layout.min.js"></script>

</body>

</html>