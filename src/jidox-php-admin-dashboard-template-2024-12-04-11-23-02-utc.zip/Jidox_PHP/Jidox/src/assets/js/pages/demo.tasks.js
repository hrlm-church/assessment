/*
Template Name: Jidox - Responsive Bootstrap 5 Admin Dashboard
Author: Mannat  


File: Task Js
*/


// Bubble theme
var quill = new Quill('#bubble-editor', {
    theme: 'bubble'
});