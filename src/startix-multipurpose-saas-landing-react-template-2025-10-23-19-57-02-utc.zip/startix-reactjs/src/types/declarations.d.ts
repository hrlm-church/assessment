declare module "bootstrap/dist/js/bootstrap.bundle.min.js";
declare module "*.css";
declare module "swiper/css";
declare module "swiper/css/navigation";
declare module "swiper/css/pagination";
declare module "swiper/css/scrollbar";
declare module "react-responsive-masonry";
