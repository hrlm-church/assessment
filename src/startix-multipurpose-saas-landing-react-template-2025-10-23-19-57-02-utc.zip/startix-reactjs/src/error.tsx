import NotFound from "./components/error";
 
export default function error() {
  return (
    <NotFound />
  )
}
