import { useEffect, useState } from "react";

const UseSticky = () => {
  const [sticky, setSticky] = useState(false);

  // throttle function
  const throttle = (fn: (...args: any[]) => void, delay: number) => {
    let lastCall = 0;
    let timeoutId: number | null = null;

    return (...args: any[]) => {
      const now = Date.now();

      if (now - lastCall >= delay) {
        lastCall = now;
        fn(...args);
      } else if (!timeoutId) {
        timeoutId = window.setTimeout(() => {
          lastCall = Date.now();
          timeoutId = null;
          fn(...args);
        }, delay - (now - lastCall));
      }
    };
  };

  useEffect(() => {
    const handleScroll = throttle(() => {
      setSticky(window.scrollY > 200);
    }, 150);

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return { sticky };
};

export default UseSticky;
