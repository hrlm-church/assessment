import { useEffect, useState } from "react";

export default function ScrollToTop() {
  const [showButton, setShowButton] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const topDistance = 600;

  // Custom throttle utility (no external dependency)
  const throttle = (fn: (...args: any[]) => void, delay: number) => {
    let lastCall = 0;
    let timeoutId: number | null = null;

    return (...args: any[]) => {
      const now = Date.now();

      if (now - lastCall >= delay) {
        lastCall = now;
        fn(...args);
      } else if (!timeoutId) {
        timeoutId = window.setTimeout(() => {
          lastCall = Date.now();
          timeoutId = null;
          fn(...args);
        }, delay - (now - lastCall));
      }
    };
  };

  useEffect(() => {
    const handleScroll = throttle(() => {
      const scrollY = window.scrollY;
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;

      setShowButton(scrollY > topDistance);

      const scrollPercent = (scrollY / (documentHeight - windowHeight)) * 100;
      setScrollProgress(scrollPercent);
    }, 150);

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
  };

  return (
    <button
      id="scrollTopButton"
      className={`startix-scrolltop ${showButton ? "scrolltop-show" : "scrolltop-hide"}`}
      onClick={scrollToTop}
      style={{ "--scroll-progress": `${scrollProgress}%` } as React.CSSProperties}
    >
      <i className="ti ti-arrow-narrow-up"></i>
    </button>
  );
}