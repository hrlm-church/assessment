import { useEffect } from "react";
import { useLocation } from "react-router-dom";

export default function ThemeProvider() {
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    let theme = "";

    if (pathname === "/home-2") theme = "two";
    else if (pathname === "/home-3") theme = "three";
    else if (pathname === "/home-4") theme = "four";
    else if (pathname === "/home-5") theme = "five";

    document.documentElement.setAttribute("data-theme", theme);

    return () => {
      document.documentElement.removeAttribute("data-theme");
    };
  }, [pathname]);

  return null;
}
