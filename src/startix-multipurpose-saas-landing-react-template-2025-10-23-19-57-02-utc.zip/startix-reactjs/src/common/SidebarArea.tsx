import { Link } from "react-router-dom";
import { useEffect, useState, useRef } from "react";

interface ProgressItem {
  title: string;
  percentage: number;
}

const progressData: ProgressItem[] = [
  { title: "Software Development", percentage: 80 },
  { title: "Data Integration", percentage: 87 },
  { title: "Analytics Success", percentage: 70 },
];

export default function SidebarArea() {
  const [progress, setProgress] = useState<number[]>(() =>
    progressData.map(() => 0)
  );
  const currentValues = useRef<number[]>(progressData.map(() => 0));
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);

    const duration = 1000;
    const fps = 60;
    const step = duration / fps;
    const increments = progressData.map((item) => item.percentage / fps);

    intervalRef.current = setInterval(() => {
      let completed = true;
      const updated = currentValues.current.map((value, index) => {
        const next = Math.min(value + increments[index], progressData[index].percentage);
        if (next < progressData[index].percentage) completed = false;
        return next;
      });

      currentValues.current = updated;
      setProgress(updated.map((v) => Math.round(v)));

      if (completed && intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }, step);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []);

  return (
    <div
      className="offcanvas offcanvas-end right-side-startix-offcanvas shadow-lg"
      tabIndex={-1}
      id="sideMenuOffcanvas"
    >
      <div className="offcanvas-header">
        <img src="/assets/img/core-img/logo-light.png" alt="" />
        <button
          type="button"
          className="btn-close btn-close-white"
          data-bs-dismiss="offcanvas"
          aria-label="Close"
        ></button>
      </div>

      <div className="offcanvas-body">
        {/* Integration Cards */}
        <div className="d-flex flex-column gap-4">
          {["Instagram", "Adobe XD", "Figma", "Slack", "Facebook", "Google Drive"].map(
            (item, i) => (
              <div key={i} className="integration-card bg-secondary mw-100">
                <img src={`/assets/img/partner-img/${6 + i}.png`} alt="" />
                <div>
                  <h5>{item}</h5>
                  <p>We must explain to you how these mistaken.</p>
                </div>
              </div>
            )
          )}
        </div>

        <div className="divider-sm"></div>

        {/* Progress Bars */}
        <div className="d-flex flex-column gap-4">
          {progressData.map((item, i) => {
            const value = progress[i] || 0;
            return (
              <div key={i} className="progress-item">
                <div className="progress-info mb-2 d-flex justify-content-between align-items-center">
                  <span>{item.title}</span>
                  <span
                    className="d-flex align-items-center gap-1"
                    style={{ marginRight: `${100 - value}%` }}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="11"
                      viewBox="0 0 14 11"
                      fill="none"
                    >
                      <path
                        d="M7.86602 10.5C7.48112 11.1667 6.51887 11.1667 6.13397 10.5L0.93782 1.5C0.55292 0.833332 1.03405 -2.67268e-07 1.80385 -1.9997e-07L12.1962 7.08554e-07C12.966 7.75852e-07 13.4471 0.833334 13.0622 1.5L7.86602 10.5Z"
                        fill="currentColor"
                      />
                    </svg>
                    <span className="percentage">{value}%</span>
                  </span>
                </div>

                <div className="progress">
                  <div
                    className="progress-bar team-progress-bar"
                    role="progressbar"
                    style={{
                      width: `${value}%`,
                      transition: "width 0.3s linear",
                    }}
                    aria-valuenow={value}
                    aria-valuemin={0}
                    aria-valuemax={100}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="divider-sm"></div>

        <Link to="/about-us" className="btn btn-primary w-100">
          <span>
            Get Started Now <i className="ti ti-arrow-up-right"></i>
          </span>
          <span>
            Get Started Now <i className="ti ti-arrow-up-right"></i>
          </span>
        </Link>
      </div>
    </div>
  );
}