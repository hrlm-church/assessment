import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import ScrollSmoother from "gsap/ScrollSmoother";
import SplitText from "gsap/SplitText";

gsap.registerPlugin(ScrollTrigger, ScrollSmoother, SplitText);

export default function AnimationProvider() {
  useEffect(() => {
    // Dynamically load Bootstrap JS once
    import("bootstrap/dist/js/bootstrap.bundle.min.js");
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;

    let smoother: ScrollSmoother | null = null;
    let ctx: gsap.Context | null = null;

    // throttle util
    const throttle = (fn: (...args: any[]) => void, delay: number) => {
      let lastCall = 0;
      let timeoutId: number | null = null;

      return (...args: any[]) => {
        const now = Date.now();

        if (now - lastCall >= delay) {
          lastCall = now;
          fn(...args);
        } else if (!timeoutId) {
          timeoutId = window.setTimeout(() => {
            lastCall = Date.now();
            timeoutId = null;
            fn(...args);
          }, delay - (now - lastCall));
        }
      };
    };

    const createAnimations = () => {
      // === Heading Chars ===
      gsap.utils.toArray<HTMLElement>(".heading-chars").forEach((el) => {
        if (!el.querySelector(".gsap-split-char")) {
          const split = new SplitText(el, { type: "chars", smartWrap: true });
          gsap.fromTo(
            split.chars,
            { y: 20, autoAlpha: 0 },
            {
              y: 0,
              autoAlpha: 1,
              scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
              stagger: 0.05,
              duration: 0.5,
              ease: "power2.out",
            }
          );
        }
      });

      // === Heading Words ===
      gsap.utils.toArray<HTMLElement>(".heading-word").forEach((el) => {
        if (!el.querySelector(".gsap-split-word")) {
          const delay = parseFloat(el.dataset.delay || "0");
          const split = new SplitText(el, { type: "words" });
          gsap.fromTo(
            split.words,
            { y: 60, autoAlpha: 0 },
            {
              y: 0,
              autoAlpha: 1,
              scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
              stagger: 0.1,
              delay,
              duration: 0.6,
              ease: "power2.out",
            }
          );
        }
      });

      // === Heading Lines ===
      gsap.utils.toArray<HTMLElement>(".heading-line").forEach((el) => {
        if (!el.querySelector(".gsap-split-line")) {
          const delay = parseFloat(el.dataset.delay || "0");
          const split = new SplitText(el, { type: "lines" });
          gsap.fromTo(
            split.lines,
            { y: 80, autoAlpha: 0 },
            {
              y: 0,
              autoAlpha: 1,
              scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
              stagger: 0.15,
              delay,
              duration: 0.7,
              ease: "power2.out",
            }
          );
        }
      });

      // === Color Change ===
      gsap.utils.toArray<HTMLElement>(".color-change").forEach((el) => {
        if (!el.querySelector(".gsap-split-char")) {
          const split = new SplitText(el, { type: "chars", smartWrap: true });
          gsap.fromTo(
            split.chars,
            { color: "#161616" },
            {
              color: "#3147FF",
              stagger: 0.05,
              scrollTrigger: { trigger: el, start: "top 80%", scrub: true },
            }
          );
        }
      });

      // === Fade In Up ===
      gsap.utils.toArray<HTMLElement>(".fadeInUp").forEach((el) => {
        const delay = parseFloat(el.dataset.delay || "0");
        gsap.fromTo(
          el,
          { y: 60, autoAlpha: 0 },
          {
            y: 0,
            autoAlpha: 1,
            scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
            duration: 0.8,
            delay,
            ease: "power2.out",
          }
        );
      });

      // === CTA Circles ===
      gsap.utils.toArray<HTMLElement>(".cta-circles span").forEach((circle) => {
        let scale = 1;
        ScrollTrigger.create({
          trigger: circle,
          start: "top bottom",
          end: "bottom top",
          onUpdate: (self) => {
            scale = self.direction === 1
              ? gsap.utils.clamp(1, 1.2, scale + 0.01)
              : gsap.utils.clamp(1, 1.2, scale - 0.01);
            gsap.to(circle, { scale, overwrite: "auto", duration: 0.2, ease: "power3.out" });
          },
        });
      });

      // === Image Anim Left ===
      gsap.utils.toArray<HTMLElement>(".img-anim-left").forEach((el) => {
        const delay = parseFloat(el.dataset.delay || "0");
        gsap.fromTo(
          el,
          { xPercent: -8, clipPath: "inset(0 100% 0 0)", opacity: 0 },
          {
            xPercent: 0,
            clipPath: "inset(0 0% 0 0)",
            opacity: 1,
            duration: 1.2,
            ease: "power2.out",
            delay,
            scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
          }
        );
      });

      // === Image Anim Right ===
      gsap.utils.toArray<HTMLElement>(".img-anim-right").forEach((el) => {
        const delay = parseFloat(el.dataset.delay || "0");
        gsap.fromTo(
          el,
          { xPercent: 8, clipPath: "inset(0 0 0 100%)", opacity: 0 },
          {
            xPercent: 0,
            clipPath: "inset(0 0 0 0%)",
            opacity: 1,
            duration: 1.2,
            ease: "power2.out",
            delay,
            scrollTrigger: { trigger: el, start: "top 95%", toggleActions: "play none none none" },
          }
        );
      });
    };

    const initAnimations = () => {
      ctx = gsap.context(() => {
        if (!ScrollSmoother.get()) {
          smoother = ScrollSmoother.create({
            smooth: 2,
            effects: true,
            smoothTouch: false,
            normalizeScroll: false,
            ignoreMobileResize: true,
            wrapper: "#smooth-wrapper",
            content: "#smooth-content",
          });
        }

        if (document.fonts && document.fonts.ready) {
          document.fonts.ready.then(() => setTimeout(createAnimations, 100));
        } else {
          setTimeout(createAnimations, 500);
        }
      });
    };

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initAnimations);
    } else {
      initAnimations();
    }

    // Throttled resize handler for ScrollTrigger.refresh()
    const handleResize = throttle(() => {
      ScrollTrigger.refresh();
    }, 400);

    window.addEventListener("resize", handleResize, { passive: true });

    // Cleanup properly
    return () => {
      if (ctx) ctx.revert();
      if (smoother) smoother.kill();
      ScrollTrigger.getAll().forEach((st) => st.kill());
      window.removeEventListener("resize", handleResize);
      document.removeEventListener("DOMContentLoaded", initAnimations);
    };
  }, []);

  return null;
}