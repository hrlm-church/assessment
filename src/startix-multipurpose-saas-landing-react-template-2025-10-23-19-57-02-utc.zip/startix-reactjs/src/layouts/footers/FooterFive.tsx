import { Link } from "react-router-dom";

export default function FooterFive() {
  return (
    <footer className="footer-section style-five">
      {/* <!-- Divider --> */}
      <div className="divider"></div>

      <div className="container">
        <div className="row g-5 g-md-4 g-xl-5">
          {/* <!-- Footer Card --> */}
          <div className="col-12 col-sm-6 col-md-4 col-xl-5">
            <div className="footer-card me-lg-5">
              {/* <!-- Footer Logo --> */}
              <Link to="/home-5" className="footer-logo mb-4">
                <img src="/assets/img/core-img/logo-four.png" alt="" />
              </Link>
              <p>Each demo built with Teba will look different. You can customize almost anything appearance
                of your website with only a few.</p>
              {/* <!-- Footer Nav --> */}
              <ul className="list-unstyled footer-nav-two theme-two">
                <li>
                  <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"
                      fill="none">
                      <path
                        d="M9.99942 0C5.92554 0 2.61133 3.31421 2.61133 7.38809C2.61133 8.72925 3.21281 10.1717 3.23801 10.2325C3.43228 10.6936 3.81559 11.4098 4.09199 11.8296L9.15761 19.505C9.36491 19.8196 9.67174 20 9.99942 20C10.3271 20 10.6339 19.8196 10.8412 19.5054L15.9073 11.8296C16.1841 11.4098 16.567 10.6936 16.7613 10.2325C16.7865 10.1721 17.3875 8.72968 17.3875 7.38809C17.3875 3.31421 14.0733 0 9.99942 0ZM15.9599 9.89526C15.7865 10.3086 15.4297 10.9748 15.1815 11.3512L10.1155 19.0269C10.0155 19.1786 9.98377 19.1786 9.88382 19.0269L4.81776 11.3512C4.56961 10.9748 4.21281 10.3081 4.0394 9.89483C4.03201 9.87701 3.48052 8.54933 3.48052 7.38809C3.48052 3.79357 6.4049 0.869187 9.99942 0.869187C13.5939 0.869187 16.5183 3.79357 16.5183 7.38809C16.5183 8.55106 15.9655 9.88223 15.9599 9.89526Z"
                        fill="#0F0F0F" />
                      <path
                        d="M9.99923 3.47656C7.84235 3.47656 6.08789 5.23145 6.08789 7.3879C6.08789 9.54436 7.84235 11.2992 9.99923 11.2992C12.1561 11.2992 13.9106 9.54436 13.9106 7.3879C13.9106 5.23145 12.1561 3.47656 9.99923 3.47656ZM9.99923 10.4301C8.32214 10.4301 6.95708 9.06544 6.95708 7.3879C6.95708 5.71037 8.32214 4.34575 9.99923 4.34575C11.6763 4.34575 13.0414 5.71037 13.0414 7.3879C13.0414 9.06544 11.6763 10.4301 9.99923 10.4301Z"
                        fill="#0F0F0F" />
                    </svg> 6391 Elgin St. Celina, USA
                  </a>
                </li>
                <li>
                  <a href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"
                      fill="none">
                      <g clip-path="url(#clip0_1_4667)">
                        <path
                          d="M18.7719 14.1213C18.7388 14.0938 14.9913 11.4275 13.9794 11.5906C13.4913 11.6769 13.2125 12.01 12.6531 12.6762C12.4985 12.8617 12.3403 13.0443 12.1788 13.2238C11.8252 13.1086 11.4804 12.9682 11.1469 12.8038C9.42533 11.9656 8.03437 10.5747 7.19625 8.85312C7.03179 8.51964 6.89143 8.1748 6.77625 7.82125C6.96 7.65312 7.2175 7.43625 7.3275 7.34375C7.99062 6.7875 8.32312 6.50812 8.40938 6.01937C8.58625 5.0075 5.90625 1.26125 5.87875 1.2275C5.7567 1.05441 5.59775 0.910578 5.41336 0.806386C5.22897 0.702193 5.02374 0.640241 4.8125 0.625C3.72625 0.625 0.625 4.6475 0.625 5.32562C0.625 5.365 0.681875 9.3675 5.6175 14.3881C10.6325 19.3181 14.635 19.375 14.6744 19.375C15.3519 19.375 19.375 16.2737 19.375 15.1875C19.3596 14.9762 19.2975 14.771 19.1932 14.5866C19.0889 14.4022 18.945 14.2433 18.7719 14.1213ZM14.605 18.1213C14.0625 18.075 10.7 17.6319 6.5 13.5063C2.35437 9.28563 1.9225 5.9175 1.87937 5.39563C2.69861 4.10978 3.68799 2.94064 4.82062 1.92C4.84562 1.945 4.87875 1.9825 4.92125 2.03125C5.78989 3.21702 6.53817 4.48642 7.155 5.82062C6.95441 6.02242 6.7424 6.21253 6.52 6.39C6.17512 6.65278 5.85843 6.95063 5.575 7.27875C5.52704 7.34604 5.4929 7.42217 5.47456 7.50274C5.45621 7.5833 5.45403 7.66671 5.46812 7.74813C5.60039 8.32108 5.80297 8.87549 6.07125 9.39875C7.03243 11.3725 8.62735 12.9672 10.6012 13.9281C11.1244 14.1968 11.6788 14.3996 12.2519 14.5319C12.3333 14.5463 12.4168 14.5443 12.4974 14.5259C12.578 14.5075 12.6541 14.4732 12.7213 14.425C13.0505 14.1404 13.3494 13.8225 13.6131 13.4762C13.8094 13.2425 14.0712 12.9306 14.1706 12.8425C15.5082 13.4587 16.7805 14.2079 17.9681 15.0787C18.02 15.1225 18.0569 15.1562 18.0812 15.1781C17.0606 16.3111 15.8912 17.3007 14.605 18.12V18.1213ZM14.375 9.375H15.625C15.6235 8.04937 15.0962 6.77847 14.1589 5.84111C13.2215 4.90375 11.9506 4.37649 10.625 4.375V5.625C11.6193 5.62599 12.5725 6.0214 13.2756 6.72445C13.9786 7.42749 14.374 8.38074 14.375 9.375Z"
                          fill="#0F0F0F" />
                        <path
                          d="M17.5 9.375H18.75C18.7475 7.22088 17.8907 5.15569 16.3675 3.6325C14.8443 2.1093 12.7791 1.25248 10.625 1.25V2.5C12.4477 2.50215 14.1951 3.22717 15.484 4.51602C16.7728 5.80486 17.4978 7.5523 17.5 9.375Z"
                          fill="#0F0F0F" />
                      </g>
                      <defs>
                        <clipPath id="clip0_1_4667">
                          <rect width="20" height="20" fill="white" />
                        </clipPath>
                      </defs>
                    </svg> +208-666-0112
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* <!-- Footer Card --> */}
          <div className="col-12 col-sm-6 col-md">
            <div className="footer-card">
              <h4 className="mb-4">Company</h4>
              <ul className="list-unstyled footer-nav">
                <li><a href="#"><i className="ti ti-chevrons-right"></i> About Us</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Our Team</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Our Program</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Work With Us</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Contact Us</a></li>
              </ul>
            </div>
          </div>

          {/* <!-- Footer Card --> */}
          <div className="col-12 col-sm-6 col-md">
            <div className="footer-card">
              <h4 className="mb-4">Quick Links</h4>
              <ul className="list-unstyled footer-nav">
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Projects</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Blog</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Our Team</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Pricing</a></li>
                <li><a href="#"><i className="ti ti-chevrons-right"></i> Projects Details</a></li>
              </ul>
            </div>
          </div>

          {/* <!-- Footer Card --> */}
          <div className="col-12 col-sm-6 col-md">
            <div className="footer-card">
              <h4 className="mb-4">Get In Touch</h4>
              <p className="mb-4 fz-16">Lorem ipsum dolor amet o adi pisicing elit sed eiusm.</p>
              {/* <!-- Social Nav --> */}
              <div className="social-nav style-three theme-two">
                <a href="#">
                  <i className="ti ti-brand-facebook"></i>
                </a>
                <a href="#">
                  <i className="ti ti-brand-linkedin"></i>
                </a>
                <a href="#">
                  <i className="ti ti-brand-x"></i>
                </a>
                <a href="#">
                  <i className="ti ti-brand-instagram"></i>
                </a>
              </div>
              <div className="d-flex align-items-center gap-3 mt-4">
                <a href="#" className="d-block"><img src="/assets/img/core-img/app-store.png" alt="" /></a>
                <a href="#" className="d-block"><img src="/assets/img/core-img/google-pay.png" alt="" /></a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Divider --> */}
      <div className="divider"></div>

      {/* <!-- Copyright --> */}
      <div className="copyright-section">
        <div className="container">
          <div
            className="d-flex flex-wrap justify-content-center align-items-center justify-content-md-between gap-3 gap-lg-4">
            <p className="mb-0 copyright">Copyright © {new Date().getFullYear()} <a href="https://themeforest.net/user/designing-world" target="_blank">Designing World</a> All rights reserved.</p>

            {/* <!-- Copyright Nav --> */}
            <ul
              className="copyright-nav theme-two justify-content-center list-unstyled d-flex flex-wrap gap-3 gap-lg-4">
              <li><a href="#">Terms &amp; Conditions</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  )
}
