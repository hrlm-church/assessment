import type { ReactNode } from "react"; 
import ScrollToTop from "../common/ScrollToTop";  
import AnimationProvider from "../common/AnimationProvider";
 
interface WrapperProps {
  children: ReactNode;
}

const Wrapper = ({ children }: WrapperProps) => {

  return (
    <>     
      {children}  
      <AnimationProvider />
      <ScrollToTop /> 
    </>
  )
};

export default Wrapper;