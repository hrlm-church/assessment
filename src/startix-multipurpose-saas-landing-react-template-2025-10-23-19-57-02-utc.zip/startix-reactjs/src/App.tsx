import { createBrowserRouter, RouterProvider } from "react-router-dom";
import HomeOne from "./components/homes/home-1";
import HomeTwo from "./components/homes/home-2";
import HomeThree from "./components/homes/home-3";
import HomeFour from "./components/homes/home-4";
import ThemeProvider from "./common/ThemeProvider";
import HomeFive from "./components/homes/home-5";
import Aboutus from "./components/Aboutus";
import Services from "./components/Services";
import ServiceDetails from "./components/ServiceDetails";
import Projects from "./components/Projects";
import ProjectDetails from "./components/ProjectDetails";
import Team from "./components/Team";
import TeamDetails from "./components/TeamDetails";
import Faq from "./components/Faq";
import Pricing from "./components/Pricing";
import Blog from "./components/Blog";
import BlogGrid from "./components/BlogGrid";
import BlogDetails from "./components/BlogDetails";
import Contact from "./components/Contact";
import NotFound from "./components/error";
import HomePreview from "./components/homes/home";

const router = createBrowserRouter([
  { path: "/", element: <><ThemeProvider /><HomePreview /></> },
  { path: "/home-1", element: <><ThemeProvider /><HomeOne /></> },
  { path: "/home-2", element: <><ThemeProvider /><HomeTwo /></> },
  { path: "/home-3", element: <><ThemeProvider /><HomeThree /></> },
  { path: "/home-4", element: <><ThemeProvider /><HomeFour /></> },
  { path: "/home-5", element: <><ThemeProvider /><HomeFive /></> },
  { path: "/about-us", element: <Aboutus /> },
  { path: "/services", element: <Services /> },
  { path: "/service-details", element: <ServiceDetails /> },
  { path: "/projects", element: <Projects /> },
  { path: "/project-details", element: <ProjectDetails /> },
  { path: "/team", element: <Team /> },
  { path: "/team-details", element: <TeamDetails /> },
  { path: "/faq", element: <Faq /> },
  { path: "/pricing", element: <Pricing /> },
  { path: "/blog", element: <Blog /> },
  { path: "/blog-grid", element: <BlogGrid /> },
  { path: "/blog-details", element: <BlogDetails /> },
  { path: "/contact", element: <Contact /> },
  { path: "*", element: <NotFound /> },
]);

function App() {

  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
