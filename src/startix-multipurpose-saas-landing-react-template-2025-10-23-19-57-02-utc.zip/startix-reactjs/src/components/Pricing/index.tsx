import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import PricingHomeOne from "../homes/home-1/PricingHomeOne";
import FaqHomeOne from "../homes/home-1/FaqHomeOne";
import Wrapper from "../../layouts/Wrapper";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import BackToTop from "../../common/BackToTop";

export default function Pricing() {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Pricing Plan" pageLink="Pricing" />
          <PricingHomeOne />
          <FaqHomeOne />
          <CtaHomeOne />
          <FooterOne />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
