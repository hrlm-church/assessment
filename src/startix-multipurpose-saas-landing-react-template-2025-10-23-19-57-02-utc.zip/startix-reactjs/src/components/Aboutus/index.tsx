import AboutArea from "./AboutArea";
import AboutStory from "./AboutStory";
import AboutTeam from "./AboutTeam"; 
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import TestimoniaHomeOne from "../homes/home-1/TestimoniaHomeOne";
import IntegrationHomeOne from "../homes/home-1/IntegrationHomeOne";
import Wrapper from "../../layouts/Wrapper";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import BackToTop from "../../common/BackToTop";
import AvoutIcon from "../../svg/AvoutIcon";

export default function Aboutus() {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="About Us" pageLink="About Us" />
          <AboutArea />
          <IntegrationHomeOne />
          <AboutStory />
          <AboutTeam />
          <TestimoniaHomeOne />
          <CtaHomeOne />
          <FooterOne />
          <BackToTop />
          <AvoutIcon />
        </div>
      </div>
    </Wrapper>
  )
}
