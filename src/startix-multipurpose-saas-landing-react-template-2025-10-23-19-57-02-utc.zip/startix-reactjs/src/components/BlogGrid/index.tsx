import BackToTop from "../../common/BackToTop";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Wrapper from "../../layouts/Wrapper";
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import BlogGridArea from "./BlogGridArea";

export default function BlogGrid () {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Blog Grid" pageLink="Blog Grid" />
          <BlogGridArea />
          <CtaHomeOne />
          <FooterOne />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
