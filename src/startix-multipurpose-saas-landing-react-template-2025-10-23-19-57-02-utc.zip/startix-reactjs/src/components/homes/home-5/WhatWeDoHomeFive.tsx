import { useEffect, useState, useRef } from "react";

interface ProgressItem {
  id: number;
  label: string;
  value: number;
  delay: number;
}

const progressData: ProgressItem[] = [
  { id: 1, label: "Software Development", value: 80, delay: 0.8 },
  { id: 2, label: "Data Integration", value: 87, delay: 1 },
  { id: 3, label: "Analytics Success", value: 70, delay: 1.2 },
];

export default function WhatWeDoHomeFive() {
  const [progressValues, setProgressValues] = useState<number[]>(
    progressData.map(() => 0)
  );

  const tiltRef = useRef<HTMLImageElement | null>(null);
  const currentValues = useRef<number[]>(progressData.map(() => 0));
  const intervalRef = useRef<number | null>(null); // use number for browser

  // Progress bar animation
  useEffect(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);

    const duration = 1000;
    const fps = 60;
    const step = duration / fps;
    const increments = progressData.map((item) => item.value / fps);

    intervalRef.current = window.setInterval(() => {
      let completed = true;

      const updated = currentValues.current.map((value, index) => {
        const next = Math.min(
          value + increments[index],
          progressData[index].value
        );
        if (next < progressData[index].value) completed = false;
        return next;
      });

      currentValues.current = updated;
      setProgressValues(updated.map((v) => Math.round(v)));

      if (completed && intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }, step);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, []);

  // Tilt effect
  useEffect(() => {
    const image = tiltRef.current;
    if (!image) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = image.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * 10;
      const rotateY = ((x - centerX) / centerX) * -10;
      image.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    };

    const handleMouseLeave = () => {
      image.style.transform = "rotateX(0deg) rotateY(0deg)";
    };

    image.addEventListener("mousemove", handleMouseMove);
    image.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      image.removeEventListener("mousemove", handleMouseMove);
      image.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  return (
    <section className="what-we-do-section">
      <div className="divider"></div>

      <div className="what-we-do-img">
        <img
          ref={tiltRef}
          className="tilt-image img-anim-left"
          src="/assets/img/bg-img/80.png"
          alt=""
          style={{ transformStyle: "preserve-3d", transition: "transform 0.2s ease" }}
        />
      </div>

      <div className="container">
        <div className="row justify-content-end">
          <div className="col-12 col-lg-6">
            <div className="section-heading">
              <span className="subtitle fadeInUp" data-delay="0.3">
                What We Do
              </span>
              <h2 className="mb-4 fadeInUp" data-delay="0.5">
                Smarter Insights. Better Business.
              </h2>
              <p className="mb-5 fadeInUp" data-delay="0.7">
                Scale your software operations through a custom engineering team.
                Meet the demand of your company's operations with a high-performing
                nearshore team skilled.
              </p>
            </div>

            <div className="d-flex flex-column gap-4">
              {progressData.map((item, index) => {
                const value = progressValues[index] || 0;
                return (
                  <div
                    key={item.id}
                    className="progress-item fadeInUp"
                    data-delay={item.delay}
                  >
                    <div className="progress-info mb-2">
                      <span>{item.label}</span>
                      <span style={{ marginRight: `${100 - value}%` }}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="14"
                          height="11"
                          viewBox="0 0 14 11"
                          fill="none"
                        >
                          <path
                            d="M7.86602 10.5C7.48112 11.1667 6.51887 11.1667 6.13397 10.5L0.93782 1.5C0.55292 0.833332 1.03405 -2.67268e-07 1.80385 -1.9997e-07L12.1962 7.08554e-07C12.966 7.75852e-07 13.4471 0.833334 13.0622 1.5L7.86602 10.5Z"
                            fill="currentColor"
                          />
                        </svg>
                      </span>
                      <span className="percentage">{value}%</span>
                    </div>
                    <div className="progress">
                      <div
                        className="progress-bar team-progress-bar"
                        role="progressbar"
                        aria-valuenow={value}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        style={{ width: `${value}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="divider"></div>
    </section>
  );
}