import HeroHomeTwo from './HeroHomeTwo'
import FeaturesHomeTwo from './FeaturesHomeTwo'
import FunfactHomeTwo from './FunfactHomeTwo'
import AboutHomeTwo from './AboutHomeTwo'
import InterfaceHomeTwo from './InterfaceHomeTwo'
import PricingHomeTwo from './PricingHomeTwo'
import TestimonialHomeTwo from './TestimonialHomeTwo'
import FaqHomeOne from '../home-1/FaqHomeOne'
import CtaHomeTwo from './CtaHomeTwo'
import BlogHomeTwo from './BlogHomeTwo' 
import Wrapper from '../../../layouts/Wrapper'
import HeaderTwo from '../../../layouts/headers/HeaderTwo'
import FooterTwo from '../../../layouts/footers/FooterTwo'
import BackToTop from '../../../common/BackToTop' 
import SvgIconTwo from '../../../svg/SvgIconTwo'

export default function HomeTwo() {
  return (
    <Wrapper>
      <HeaderTwo />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <HeroHomeTwo />
          <FeaturesHomeTwo />
          <FunfactHomeTwo />
          <AboutHomeTwo />
          <InterfaceHomeTwo />
          <PricingHomeTwo />
          <TestimonialHomeTwo />
          <FaqHomeOne />
          <CtaHomeTwo />
          <BlogHomeTwo />
          <FooterTwo />
        </div>
      </div>
       <SvgIconTwo />
       <BackToTop />
    </Wrapper>
  )
}
