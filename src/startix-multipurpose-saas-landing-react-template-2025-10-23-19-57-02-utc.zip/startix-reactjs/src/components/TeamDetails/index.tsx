import BackToTop from "../../common/BackToTop";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Wrapper from "../../layouts/Wrapper";
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import TeamContactArea from "./TeamContactArea";
import TeamDetailsArea from "./TeamDetailsArea";

export default function TeamDetails() {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Team Details" pageLink="Team Details" />
          <TeamDetailsArea />
          <TeamContactArea />
          <CtaHomeOne />
          <FooterOne />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
