import BackToTop from "../../common/BackToTop";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Wrapper from "../../layouts/Wrapper";
import ServiceDetailsIcon from "../../svg/ServiceDetailsIcon";
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import ServiceDetailsArea from "./ServiceDetailsArea";

export default function ServiceDetails() {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Service Details" pageLink="Service Details" />
          <ServiceDetailsArea />                      
          <CtaHomeOne />
          <FooterOne />
          <ServiceDetailsIcon />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
