import BackToTop from "../../common/BackToTop";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Wrapper from "../../layouts/Wrapper";
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import BlogArea from "./BlogArea";

export default function Blog() {
  return (
    <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Blog" pageLink="Blog Standard" />
          <BlogArea />           
          <CtaHomeOne />
          <FooterOne />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
