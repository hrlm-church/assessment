import BackToTop from "../../common/BackToTop";
import Breadcrumb from "../../common/Breadcrumb";
import FooterOne from "../../layouts/footers/FooterOne";
import HeaderOne from "../../layouts/headers/HeaderOne";
import Wrapper from "../../layouts/Wrapper";
import CtaHomeOne from "../homes/home-1/CtaHomeOne"; 
import BlogDetailsArea from "./BlogDetailsArea";

export default function BlogDetails() {
  return (
     <Wrapper>
      <HeaderOne />
      <div id="smooth-wrapper">
        <div id="smooth-content">
          <Breadcrumb title="Blog Details" pageLink="Blog Details" />
          <BlogDetailsArea />
          <CtaHomeOne />
          <FooterOne />
        </div>
      </div>
       <BackToTop />
    </Wrapper>
  )
}
