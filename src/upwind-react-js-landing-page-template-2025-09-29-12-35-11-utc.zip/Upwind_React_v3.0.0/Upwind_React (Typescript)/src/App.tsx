import { useState, useEffect } from "react";
import './assets/css/tailwind.css';

import {
  Route,
  Routes
} from "react-router-dom";


import Index from "./pages/index.js";
import IndexTwo from "./pages/index-two.js";
import IndexThree from "./pages/index-three.js";

import IndexFour from "./pages/index-four.js";
import IndexFive from "./pages/index-five.js";
import IndexSix from "./pages/index-six.js";
import IndexSeven from "./pages/index-seven.js";
import IndexEight from "./pages/index-eight.js";
import Login from './pages/auth/login.js';
import Signup from './pages/auth/signup.js';
import ResetPassword from './pages/auth/reset-password.js';
import Loader from "./component/loader.js";
import BlogDetail from "./pages/blog-detail.js";
import PortfolioDetail from "./pages/portfolio-detail.js";
import IndexNine from "./pages/index-nine.js";
import { scrollSpy } from "react-scroll";
import IndexTen from "./pages/index-ten.js";
import IndexEleven from "./pages/index-eleven.js";
import IndexTwelve from "./pages/index-twelve.js";

export default function App() {

  const [loading, setLoading] = useState(false);
  useEffect(() => {
    document.documentElement.setAttribute('dir', 'ltr');
    handleRouteChange();
    scrollSpy.update();
  }, []);


  // Route change method
  const handleRouteChange = () => {
    setLoading(false);
  }

  return (
    <>
      {loading && <Loader />}
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/index" element={<Index />} />
        <Route path="/index-two" element={<IndexTwo />} />
        <Route path="/index-three" element={<IndexThree />} />
        <Route path="/index-four" element={<IndexFour />} />
        <Route path="/index-five" element={<IndexFive />} />
        <Route path="/index-six" element={<IndexSix />} />
        <Route path="/index-seven" element={<IndexSeven />} />
        <Route path="/index-eight" element={<IndexEight />} />
        <Route path="/index-nine" element={<IndexNine />} />
        <Route path="/index-ten" element={<IndexTen />} />
        <Route path="/index-eleven" element={<IndexEleven />} />
        <Route path="/index-twelve" element={<IndexTwelve />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/blog-detail" element={<BlogDetail/>} />
        <Route path="/blog-detail/:id" element={<BlogDetail/>} />
        <Route path="/portfolio-detail" element={<PortfolioDetail/>} />
      </Routes>
    </>
  );

}
