declare namespace JSX {
  interface IntrinsicElements {
    marquee: any;
  }
}